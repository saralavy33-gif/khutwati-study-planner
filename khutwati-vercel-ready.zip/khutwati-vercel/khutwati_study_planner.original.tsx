import React, { useState, useEffect, useMemo, useRef } from 'react';
import {
  Calendar as CalendarIcon,
  Clock,
  BookOpen,
  CheckCircle2,
  AlertCircle,
  Sparkles,
  Flame,
  Award,
  Play,
  Pause,
  RotateCcw,
  Volume2,
  VolumeX,
  Printer,
  ChevronRight,
  ChevronLeft,
  Settings,
  BarChart2,
  Home,
  Check,
  Plus,
  Trash2,
  Sun,
  Moon,
  X,
  Lightbulb,
  ArrowRight,
  TrendingUp,
  FileText,
  Layout,
  Target
} from 'lucide-react';

// SAMPLE HIGH SCHOOL SUBJECTS IN KUWAIT
const DEFAULT_SAMPLE_SUBJECTS = [
  { id: 'sub_1', name: 'الرياضيات', totalLessons: 12, maxLessonsPerDay: 2, difficulty: 'hard', examDate: '2026-12-10', color: 'from-blue-600 to-indigo-600' },
  { id: 'sub_2', name: 'الفيزياء', totalLessons: 10, maxLessonsPerDay: 2, difficulty: 'hard', examDate: '2026-12-13', color: 'from-violet-600 to-purple-600' },
  { id: 'sub_3', name: 'اللغة العربية', totalLessons: 8, maxLessonsPerDay: 3, difficulty: 'medium', examDate: '2026-12-16', color: 'from-emerald-600 to-teal-600' },
  { id: 'sub_4', name: 'اللغة الإنجليزية', totalLessons: 8, maxLessonsPerDay: 3, difficulty: 'medium', examDate: '2026-12-18', color: 'from-amber-500 to-orange-600' },
  { id: 'sub_5', name: 'الكيمياء', totalLessons: 9, maxLessonsPerDay: 2, difficulty: 'hard', examDate: '2026-12-21', color: 'from-rose-600 to-pink-600' },
  { id: 'sub_6', name: 'التربية الإسلامية', totalLessons: 6, maxLessonsPerDay: 4, difficulty: 'easy', examDate: '2026-12-23', color: 'from-cyan-600 to-blue-600' }
];

const MOTIVATIONAL_QUOTES = [
  "كل خطوة صغيرة تقرّبك من هدفك الكبير 🌟",
  "إنجاز اليوم هو بداية النجاح الباهر لغد 🚀",
  "استمر بتفوق، حديقة إنجازاتك تزهر مع كل درس تنهيه 🌸",
  "لا تستعجل النتيجة، استمتع بالتقدم اليومي الضخم 💡",
  "التنظيم والهدوء هما سر أعلى الدرجات في الثانوية 🎓",
  "مو لازم تكون مثالي، المهم أن تواصل وتستمر بنجاح 💪"
];

// UTILITY FUNCTIONS FOR DATES
const formatDate = (dateObj) => {
  const d = new Date(dateObj);
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
};

const getArabicDayName = (dateStr) => {
  const days = ['الأحد', 'الإثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت'];
  const d = new Date(dateStr);
  return days[d.getDay()];
};

const ARABIC_MONTHS = [
  'يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو',
  'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر'
];

export default function App() {
  // App Navigation & Display
  const [darkMode, setDarkMode] = useState(true);
  const [activeTab, setActiveTab] = useState('welcome'); // welcome, onboarding, dashboard, calendar, focus, progress, guide, settings

  // Student Profile Info
  const [studentInfo, setStudentInfo] = useState({
    name: 'أحمد',
    grade: 'الصف الثاني عشر',
    track: 'علمي'
  });

  // Scheduling Inputs
  const [subjects, setSubjects] = useState(DEFAULT_SAMPLE_SUBJECTS);
  const [studyStartDate, setStudyStartDate] = useState('2026-11-01');
  const [dailyHours, setDailyHours] = useState(3);
  const [restDays, setRestDays] = useState(['الجمعة']);
  const [extraRevisionRequests, setExtraRevisionRequests] = useState([]);

  // Onboarding Step State (5 Steps)
  const [onboardingStep, setOnboardingStep] = useState(1);
  const [newSubjectName, setNewSubjectName] = useState('');
  const [newSubjectExamDate, setNewSubjectExamDate] = useState('2026-12-15');

  // Interactive Calendar View Navigation State
  const [currentCalendarDate, setCurrentCalendarDate] = useState(new Date(2026, 10, 1)); // Nov 2026 default
  const [selectedCalendarDay, setSelectedCalendarDay] = useState(null);
  const [selectedSubjectFilter, setSelectedSubjectFilter] = useState('all');

  // Completion Tracking
  const [completedTaskIds, setCompletedTaskIds] = useState([]);
  const [selectedTaskForReview, setSelectedTaskForReview] = useState(null);
  const [toastMessage, setToastMessage] = useState(null);
  const [showResetConfirmModal, setShowResetConfirmModal] = useState(false);
  const [showPrintModal, setShowPrintModal] = useState(false);
  const [currentQuoteIndex, setCurrentQuoteIndex] = useState(0);

  // Focus Timer States
  const [focusTime, setFocusTime] = useState(25 * 60);
  const [focusMode, setFocusMode] = useState('study'); // 'study' or 'break'
  const [isTimerRunning, setIsTimerRunning] = useState(false);
  const [soundType, setSoundType] = useState('none');
  const [soundVolume, setSoundVolume] = useState(0.1);
  const audioCtxRef = useRef(null);
  const gainNodeRef = useRef(null);

  const showNotification = (msg) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(null);
    }, 4000);
  };

  // Load saved state
  useEffect(() => {
    const saved = localStorage.getItem('khutwati_app_data_v6');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (parsed.studentInfo) setStudentInfo(parsed.studentInfo);
        if (parsed.subjects) setSubjects(parsed.subjects);
        if (parsed.studyStartDate) setStudyStartDate(parsed.studyStartDate);
        if (parsed.dailyHours) setDailyHours(parsed.dailyHours);
        if (parsed.restDays) setRestDays(parsed.restDays);
        if (parsed.completedTaskIds) setCompletedTaskIds(parsed.completedTaskIds);
        if (parsed.extraRevisionRequests) setExtraRevisionRequests(parsed.extraRevisionRequests);
      } catch (e) {
        console.error('Error loading saved state', e);
      }
    }
  }, []);

  // Save state
  useEffect(() => {
    const dataToSave = {
      studentInfo,
      subjects,
      studyStartDate,
      dailyHours,
      restDays,
      completedTaskIds,
      extraRevisionRequests
    };
    localStorage.setItem('khutwati_app_data_v6', JSON.stringify(dataToSave));
  }, [studentInfo, subjects, studyStartDate, dailyHours, restDays, completedTaskIds, extraRevisionRequests]);

  // Rotate Motivational Quotes
  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentQuoteIndex(prev => (prev + 1) % MOTIVATIONAL_QUOTES.length);
    }, 9000);
    return () => clearInterval(interval);
  }, []);

  // Audio Synthesizer for Ambient Focus
  useEffect(() => {
    if (soundType === 'none') {
      if (audioCtxRef.current) {
        audioCtxRef.current.close();
        audioCtxRef.current = null;
      }
      return;
    }

    try {
      const ctx = new (window.AudioContext || window.webkitAudioContext)();
      audioCtxRef.current = ctx;

      const bufferSize = ctx.sampleRate * 2;
      const noiseBuffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
      const output = noiseBuffer.getChannelData(0);
      for (let i = 0; i < bufferSize; i++) {
        output[i] = Math.random() * 2 - 1;
      }

      const whiteNoise = ctx.createBufferSource();
      whiteNoise.buffer = noiseBuffer;
      whiteNoise.loop = true;

      const filter = ctx.createBiquadFilter();
      filter.type = soundType === 'rain' ? 'lowpass' : 'bandpass';
      filter.frequency.value = soundType === 'rain' ? 800 : 400;

      const gain = ctx.createGain();
      gain.gain.value = soundVolume;
      gainNodeRef.current = gain;

      whiteNoise.connect(filter);
      filter.connect(gain);
      gain.connect(ctx.destination);
      whiteNoise.start();
    } catch (e) {
      console.warn('Audio playback error', e);
    }

    return () => {
      if (audioCtxRef.current) {
        audioCtxRef.current.close();
        audioCtxRef.current = null;
      }
    };
  }, [soundType]);

  // Update sound volume dynamically
  useEffect(() => {
    if (gainNodeRef.current) {
      gainNodeRef.current.gain.value = soundVolume;
    }
  }, [soundVolume]);

  // Pomodoro Timer Logic
  useEffect(() => {
    let timer = null;
    if (isTimerRunning && focusTime > 0) {
      timer = setInterval(() => setFocusTime(prev => prev - 1), 1000);
    } else if (focusTime === 0) {
      if (focusMode === 'study') {
        showNotification('أحسنت بطل! انتهت جلسة التركيز. وقت الاستراحة القصيرة (5 دقائق) ☕');
        setFocusMode('break');
        setFocusTime(5 * 60);
      } else {
        showNotification('انتهت استراحة الـ 5 دقائق! جاهز لجلسة تركيز جديدة؟ 🚀');
        setFocusMode('study');
        setFocusTime(25 * 60);
      }
      setIsTimerRunning(false);
    }
    return () => clearInterval(timer);
  }, [isTimerRunning, focusTime, focusMode]);

  // CONTINUOUS LEARNING SCHEDULING ALGORITHM
  // Finish 1 subject 100% continuous day-after-day, then move to next
  // First Exam Subject is placed LAST in prep phase!
  const generatedPlan = useMemo(() => {
    if (!subjects || subjects.length === 0 || !studyStartDate) return null;

    // 1. Sort subjects by exam date
    const sortedExams = [...subjects].sort((a, b) => new Date(a.examDate) - new Date(b.examDate));
    const firstExamSub = sortedExams[0];
    const otherSubs = sortedExams.slice(1);

    // 2. Continuous Subject Order: Other subjects first, First Exam subject LAST in phase A
    const continuousOrderedSubjects = [...otherSubs, firstExamSub];

    const firstExamDateStr = sortedExams[0].examDate;
    const lastExamDateStr = sortedExams[sortedExams.length - 1].examDate;

    const startDate = new Date(studyStartDate);
    const firstExamDate = new Date(firstExamDateStr);
    const lastExamDate = new Date(lastExamDateStr);

    const schedule = [];
    let currDate = new Date(startDate);

    // Build subject lesson queues
    let subjectQueues = continuousOrderedSubjects.map(sub => {
      const items = [];
      for (let i = 1; i <= sub.totalLessons; i++) {
        items.push({
          id: `${sub.id}_l_${i}`,
          subjectId: sub.id,
          subjectName: sub.name,
          title: `الدرس ${i}: ${sub.name}`,
          type: 'study'
        });
      }

      // Add extra revision requests if any
      const extraRevs = extraRevisionRequests.filter(req => req.subjectId === sub.id);
      extraRevs.forEach((req, idx) => {
        items.push({
          id: `${sub.id}_extra_rev_${idx + 1}`,
          subjectId: sub.id,
          subjectName: sub.name,
          title: `📖 جلسة مراجعة وتثبيت إضافية: ${sub.name}`,
          type: 'extra_revision'
        });
      });

      return {
        subject: sub,
        items: items
      };
    });

    let currentSubjectIndex = 0;

    // PHASE A: Pre-Exam Preparation (Continuous Subject Learning)
    while (currDate < firstExamDate) {
      const dateStr = formatDate(currDate);
      const dayName = getArabicDayName(dateStr);
      const isRest = restDays.includes(dayName) || restDays.includes(dateStr);

      const daySchedule = {
        date: dateStr,
        dayName,
        isRest,
        phase: 'prep',
        items: [],
        mainSubjectName: null,
        mainSubjectId: null
      };

      if (!isRest && currentSubjectIndex < subjectQueues.length) {
        let activeQueueObj = subjectQueues[currentSubjectIndex];

        // Move to next subject if current subject is completed
        while (activeQueueObj && activeQueueObj.items.length === 0 && currentSubjectIndex < subjectQueues.length - 1) {
          currentSubjectIndex++;
          activeQueueObj = subjectQueues[currentSubjectIndex];
        }

        if (activeQueueObj && activeQueueObj.items.length > 0) {
          daySchedule.mainSubjectName = activeQueueObj.subject.name;
          daySchedule.mainSubjectId = activeQueueObj.subject.id;

          let lessonsScheduledToday = 0;
          const maxLessons = activeQueueObj.subject.maxLessonsPerDay || 2;

          while (
            activeQueueObj.items.length > 0 &&
            lessonsScheduledToday < maxLessons
          ) {
            const task = activeQueueObj.items.shift();
            daySchedule.items.push(task);
            lessonsScheduledToday++;
          }
        }
      }

      schedule.push(daySchedule);
      currDate.setDate(currDate.getDate() + 1);
    }

    // PHASE B: Examination Period (Intensive Evening Revisions)
    while (currDate <= lastExamDate) {
      const dateStr = formatDate(currDate);
      const dayName = getArabicDayName(dateStr);

      const examToday = sortedExams.find(s => s.examDate === dateStr);
      const upcomingExams = sortedExams.filter(s => new Date(s.examDate) > currDate);
      const nextExam = upcomingExams[0] || null;

      const daySchedule = {
        date: dateStr,
        dayName,
        isRest: false,
        phase: 'exam_period',
        examToday: examToday ? examToday.name : null,
        nextExam: nextExam ? nextExam.name : null,
        items: [],
        mainSubjectName: examToday ? `اختبار ${examToday.name}` : (nextExam ? `مراجعة ${nextExam.name}` : 'مراجعة ختامية'),
        mainSubjectId: examToday ? examToday.id : (nextExam ? nextExam.id : null)
      };

      if (examToday) {
        daySchedule.items.push({
          id: `exam_${examToday.id}_${dateStr}`,
          subjectId: examToday.id,
          subjectName: examToday.name,
          title: `📝 تقديم اختبار: ${examToday.name}`,
          type: 'exam'
        });
      }

      if (nextExam) {
        daySchedule.items.push({
          id: `rev_evening_${nextExam.id}_${dateStr}`,
          subjectId: nextExam.id,
          subjectName: nextExam.name,
          title: `🌙 مراجعة مسائية مكثفة لاختبار: ${nextExam.name}`,
          type: 'revision'
        });
      }

      schedule.push(daySchedule);
      currDate.setDate(currDate.getDate() + 1);
    }

    const totalRemainingLessons = subjectQueues.reduce((acc, q) => acc + q.items.length, 0);

    return {
      schedule,
      sortedSubjects: sortedExams,
      firstExamDate: firstExamDateStr,
      lastExamDate: lastExamDateStr,
      isFeasible: totalRemainingLessons === 0,
      unassignedCount: totalRemainingLessons
    };
  }, [subjects, studyStartDate, dailyHours, restDays, extraRevisionRequests]);

  // Overall Statistics
  const overallStats = useMemo(() => {
    if (!generatedPlan) return { totalTasks: 0, completedTasks: 0, progressPct: 0 };
    let total = 0;
    generatedPlan.schedule.forEach(day => {
      total += day.items.length;
    });
    const completed = completedTaskIds.length;
    const progressPct = total > 0 ? Math.min(100, Math.round((completed / total) * 100)) : 0;
    return { totalTasks: total, completedTasks: completed, progressPct };
  }, [generatedPlan, completedTaskIds]);

  // Helpers for Onboarding
  const updateSubjectDetail = (id, field, value) => {
    setSubjects(prev => prev.map(s => s.id === id ? { ...s, [field]: value } : s));
  };

  const handleAddSubjectInStep2 = () => {
    if (!newSubjectName.trim()) return;
    const newSub = {
      id: `sub_${Date.now()}`,
      name: newSubjectName.trim(),
      totalLessons: 8,
      maxLessonsPerDay: 2,
      difficulty: 'medium',
      examDate: newSubjectExamDate,
      color: 'from-indigo-600 to-purple-600'
    };
    setSubjects(prev => [...prev, newSub]);
    setNewSubjectName('');
  };

  const handleRemoveSubject = (id) => {
    if (subjects.length <= 1) {
      showNotification('يجب إبقاء مادة واحدة على الأقل في الجدول!');
      return;
    }
    setSubjects(prev => prev.filter(s => s.id !== id));
  };

  const suggestThirtyDaysBeforeFirstExam = () => {
    if (!subjects || subjects.length === 0) return;
    const sorted = [...subjects].sort((a, b) => new Date(a.examDate) - new Date(b.examDate));
    const firstExamDateStr = sorted[0].examDate;
    const d = new Date(firstExamDateStr);
    d.setDate(d.getDate() - 30);
    const suggestedStr = formatDate(d);
    setStudyStartDate(suggestedStr);
    showNotification(`تم اقتراح موعد البدء (${suggestedStr}) - أي قبل أول اختبار بـ 30 يوماً! 🚀`);
  };

  const toggleTaskCompletion = (taskId) => {
    setCompletedTaskIds(prev => 
      prev.includes(taskId) ? prev.filter(id => id !== taskId) : [...prev, taskId]
    );
  };

  const handleComprehensionFeedback = (level) => {
    if (!selectedTaskForReview) return;
    if (level === 'easy') {
      showNotification(`رائع جداً! تم الاعتماد وتأكيد إتقانك لدرس (${selectedTaskForReview.title}) 🌟`);
    } else if (level === 'review' || level === 'hard') {
      setExtraRevisionRequests(prev => [
        ...prev,
        {
          subjectId: selectedTaskForReview.subjectId,
          subjectName: selectedTaskForReview.subjectName,
          timestamp: Date.now()
        }
      ]);
      showNotification(`تم إضافة جلسة مراجعة وتثبيت إضافية لمادة (${selectedTaskForReview.subjectName}) وإعادة جدولة الخطة تلقائياً! 📖✨`);
    }
    setSelectedTaskForReview(null);
  };

  const handleFullResetApp = () => {
    localStorage.removeItem('khutwati_app_data_v6');
    setStudentInfo({ name: 'أحمد', grade: 'الصف الثاني عشر', track: 'علمي' });
    setSubjects(DEFAULT_SAMPLE_SUBJECTS);
    setStudyStartDate('2026-11-01');
    setDailyHours(3);
    setRestDays(['الجمعة']);
    setCompletedTaskIds([]);
    setExtraRevisionRequests([]);
    setShowResetConfirmModal(false);
    setActiveTab('welcome');
    setOnboardingStep(1);
    showNotification('تمت إعادة ضبط جميع البيانات بنجاح! 🌱');
  };

  // Calendar Grid Month Computation Logic
  const calendarMonthDays = useMemo(() => {
    const year = currentCalendarDate.getFullYear();
    const month = currentCalendarDate.getMonth();
    
    const firstDayOfMonth = new Date(year, month, 1);
    const lastDayOfMonth = new Date(year, month + 1, 0);
    
    const startingDayOfWeek = firstDayOfMonth.getDay(); // 0 is Sunday in JS
    const daysInMonth = lastDayOfMonth.getDate();
    
    const days = [];
    
    // Padding days before month starts
    for (let i = 0; i < startingDayOfWeek; i++) {
      days.push({ isPadding: true, dateStr: null });
    }
    
    // Days of current month
    for (let day = 1; day <= daysInMonth; day++) {
      const d = new Date(year, month, day);
      const dateStr = formatDate(d);
      const daySchedule = generatedPlan?.schedule?.find(s => s.date === dateStr) || null;
      days.push({
        isPadding: false,
        dayNumber: day,
        dateStr,
        daySchedule
      });
    }
    
    return days;
  }, [currentCalendarDate, generatedPlan]);

  const handlePrevMonth = () => {
    setCurrentCalendarDate(prev => new Date(prev.getFullYear(), prev.getMonth() - 1, 1));
  };

  const handleNextMonth = () => {
    setCurrentCalendarDate(prev => new Date(prev.getFullYear(), prev.getMonth() + 1, 1));
  };

  // Today Schedule Object
  const todayStr = formatDate(new Date());
  const todayScheduleObj = generatedPlan?.schedule?.find(s => s.date === todayStr) || 
                          generatedPlan?.schedule?.find(s => s.items && s.items.length > 0);

  return (
    <div className={`min-h-screen font-tajawal transition-colors duration-300 ${darkMode ? 'dark bg-[#0b0c16] text-slate-100' : 'bg-[#FAF9FF] text-slate-800'}`} dir="rtl">
      
      {/* SYSTEM TOAST NOTIFICATION */}
      {toastMessage && (
        <div className="fixed top-6 left-1/2 -translate-x-1/2 z-50 bg-gradient-to-r from-indigo-900 to-purple-900 text-white px-6 py-3.5 rounded-2xl shadow-2xl flex items-center gap-3 border border-indigo-500/40 text-xs sm:text-sm font-bold backdrop-blur-xl animate-bounce">
          <Sparkles className="w-5 h-5 text-amber-400 flex-shrink-0 animate-pulse" />
          <span>{toastMessage}</span>
          <button onClick={() => setToastMessage(null)} className="mr-2 text-indigo-300 hover:text-white"><X className="w-4 h-4" /></button>
        </div>
      )}

      {/* HEADER / NAVIGATION BAR */}
      {activeTab !== 'welcome' && (
        <header className="sticky top-0 z-40 bg-white/70 dark:bg-[#0f1123]/80 backdrop-blur-xl border-b border-slate-200/60 dark:border-slate-800/80">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-18 flex items-center justify-between py-3">
            <div className="flex items-center gap-3 cursor-pointer group" onClick={() => setActiveTab('dashboard')}>
              <div className="w-11 h-11 rounded-2xl bg-gradient-to-tr from-indigo-600 via-purple-600 to-pink-500 flex items-center justify-center text-white font-black text-2xl shadow-lg shadow-indigo-500/20 group-hover:scale-105 transition-all">
                خ
              </div>
              <div>
                <h1 className="text-xl font-black bg-gradient-to-r from-indigo-500 via-purple-400 to-pink-500 bg-clip-text text-transparent">
                  خطوتي
                </h1>
                <p className="text-[10px] text-slate-500 dark:text-slate-400 -mt-1 font-bold">إعداد: أ. ساره الغريب | كل خطوة تزرع نجاحًا</p>
              </div>
            </div>

            {/* Desktop Navigation */}
            <nav className="hidden lg:flex items-center gap-1.5 bg-slate-100/80 dark:bg-slate-900/80 p-1.5 rounded-2xl border border-slate-200/60 dark:border-slate-800">
              <button 
                onClick={() => setActiveTab('dashboard')} 
                className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 ${activeTab === 'dashboard' ? 'bg-indigo-600 text-white shadow-md' : 'text-slate-600 dark:text-slate-400 hover:text-indigo-500'}`}>
                <Home className="w-4 h-4" /> اليوم
              </button>
              <button 
                onClick={() => setActiveTab('calendar')} 
                className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 ${activeTab === 'calendar' ? 'bg-indigo-600 text-white shadow-md' : 'text-slate-600 dark:text-slate-400 hover:text-indigo-500'}`}>
                <CalendarIcon className="w-4 h-4" /> الرزنامة الشهرية
              </button>
              <button 
                onClick={() => setActiveTab('focus')} 
                className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 ${activeTab === 'focus' ? 'bg-indigo-600 text-white shadow-md' : 'text-slate-600 dark:text-slate-400 hover:text-indigo-500'}`}>
                <Clock className="w-4 h-4 text-amber-400" /> مساحة التركيز
              </button>
              <button 
                onClick={() => setActiveTab('progress')} 
                className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 ${activeTab === 'progress' ? 'bg-indigo-600 text-white shadow-md' : 'text-slate-600 dark:text-slate-400 hover:text-indigo-500'}`}>
                <BarChart2 className="w-4 h-4" /> تقدمي
              </button>
              <button 
                onClick={() => setActiveTab('guide')} 
                className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 ${activeTab === 'guide' ? 'bg-indigo-600 text-white shadow-md' : 'text-slate-600 dark:text-slate-400 hover:text-indigo-500'}`}>
                <Lightbulb className="w-4 h-4 text-amber-400" /> كيف أدرس؟
              </button>
            </nav>

            <div className="flex items-center gap-2">
              <button 
                onClick={() => setShowPrintModal(true)}
                className="hidden sm:flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-indigo-600 hover:text-white transition-all text-xs font-bold">
                <Printer className="w-4 h-4" /> طباعة
              </button>

              <button 
                onClick={() => setDarkMode(!darkMode)}
                className="p-2.5 rounded-xl border border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-all">
                {darkMode ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4 text-slate-600" />}
              </button>
              
              <button 
                onClick={() => setActiveTab('settings')}
                className="p-2.5 rounded-xl border border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-all">
                <Settings className="w-4 h-4" />
              </button>
            </div>
          </div>
        </header>
      )}

      {/* MOBILE BOTTOM NAVIGATION */}
      {activeTab !== 'welcome' && (
        <div className="lg:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/90 dark:bg-[#0f1123]/90 backdrop-blur-xl border-t border-slate-200/80 dark:border-slate-800 px-3 py-2 flex justify-around items-center">
          <button 
            onClick={() => setActiveTab('dashboard')} 
            className={`flex flex-col items-center gap-1 p-1 text-[11px] font-bold ${activeTab === 'dashboard' ? 'text-indigo-500' : 'text-slate-500 dark:text-slate-400'}`}>
            <Home className="w-5 h-5" /> اليوم
          </button>
          <button 
            onClick={() => setActiveTab('calendar')} 
            className={`flex flex-col items-center gap-1 p-1 text-[11px] font-bold ${activeTab === 'calendar' ? 'text-indigo-500' : 'text-slate-500 dark:text-slate-400'}`}>
            <CalendarIcon className="w-5 h-5" /> الرزنامة
          </button>
          <button 
            onClick={() => setActiveTab('focus')} 
            className={`flex flex-col items-center gap-1 p-1 text-[11px] font-bold ${activeTab === 'focus' ? 'text-indigo-500' : 'text-slate-500 dark:text-slate-400'}`}>
            <Clock className="w-5 h-5" /> التركيز
          </button>
          <button 
            onClick={() => setActiveTab('progress')} 
            className={`flex flex-col items-center gap-1 p-1 text-[11px] font-bold ${activeTab === 'progress' ? 'text-indigo-500' : 'text-slate-500 dark:text-slate-400'}`}>
            <BarChart2 className="w-5 h-5" /> تقدمي
          </button>
        </div>
      )}

      {/* MAIN CONTENT AREA */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 pb-28 lg:pb-12">
        
        {/* 1. WELCOME HERO SCREEN */}
        {activeTab === 'welcome' && (
          <div className="min-h-[85vh] flex flex-col items-center justify-center text-center max-w-4xl mx-auto py-12 relative">
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] bg-gradient-to-tr from-indigo-600/20 via-purple-600/20 to-pink-500/20 blur-[120px] rounded-full pointer-events-none" />

            <div className="inline-flex items-center gap-2 px-5 py-2.5 rounded-full bg-indigo-500/10 border border-indigo-500/30 text-indigo-400 text-xs font-bold mb-8 animate-pulse backdrop-blur-md">
              <Sparkles className="w-4 h-4 text-amber-400" /> المنصة الأذكى لتخطيط وتنظيم جدول الثانوية العامة بالكويت
            </div>
            
            <h1 className="text-5xl sm:text-7xl font-black tracking-tight text-slate-900 dark:text-white mb-4">
              خطوتي <span className="bg-gradient-to-r from-indigo-500 via-purple-400 to-pink-500 bg-clip-text text-transparent">| KHUTWATI</span>
            </h1>
            
            <p className="text-2xl font-black text-indigo-400 mb-6">
              "كل خطوة تزرع نجاحًا"
            </p>

            <p className="text-slate-600 dark:text-slate-300 text-base sm:text-xl leading-relaxed mb-10 max-w-2xl font-medium">
              نظام المذاكرة المتواصلة: ادرس مادة واحدة بتركيز تام يوماً بعد يوم حتى تنهيها، ثم انتقل للبعدها! مع مراجعات مسائية مكثفة ورزنامة بصرية تفاعلية.
            </p>

            <div className="flex flex-col sm:flex-row items-center gap-4 w-full justify-center max-w-[500px] z-10">
              <button 
                onClick={() => {
                  setOnboardingStep(1);
                  setActiveTab('onboarding');
                }}
                className="relative group w-full py-6 px-12 rounded-3xl bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-600 text-white font-black text-2xl sm:text-3xl tracking-wide shadow-[0_10px_40px_rgba(99,102,241,0.5)] hover:shadow-[0_20px_60px_rgba(168,85,247,0.7)] hover:scale-105 active:scale-98 transition-all duration-300 ease-out flex items-center justify-center gap-4 border-2 border-white/20 overflow-hidden cursor-pointer">
                {/* Glowing shimmer animated background overlay */}
                <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/25 to-transparent -translate-x-full group-hover:translate-x-full transition-transform duration-1000 ease-in-out pointer-events-none" />
                
                <span className="relative z-10 drop-shadow-md">ابدأ رحلتك الآن</span>
                
                <div className="relative z-10 w-10 h-10 sm:w-12 sm:h-12 rounded-2xl bg-white/20 backdrop-blur-md flex items-center justify-center group-hover:bg-white group-hover:text-indigo-600 transition-all duration-300 group-hover:rotate-12 shadow-inner">
                  <ArrowRight className="w-6 h-6 sm:w-7 sm:h-7 rotate-180 group-hover:-translate-x-1 transition-transform" />
                </div>
              </button>
            </div>
          </div>
        )}

        {/* 2. ONBOARDING WIZARD (5 STEPS) */}
        {activeTab === 'onboarding' && (
          <div className="max-w-3xl mx-auto bg-white/80 dark:bg-[#121427]/80 backdrop-blur-xl border border-slate-200/80 dark:border-slate-800 rounded-3xl p-6 sm:p-10 shadow-2xl">
            
            {/* Step Progress Header */}
            <div className="flex items-center justify-between mb-8 pb-4 border-b border-slate-200 dark:border-slate-800">
              <div>
                <span className="text-xs font-black text-indigo-500">الخطوة {onboardingStep} من 5</span>
                <h3 className="text-sm font-bold text-slate-800 dark:text-slate-200 mt-0.5">
                  {onboardingStep === 1 && 'المعلومات الشخصية والمرحلة'}
                  {onboardingStep === 2 && 'المواد وتواريخ الاختبارات'}
                  {onboardingStep === 3 && 'تفاصيل الدروس والمستويات'}
                  {onboardingStep === 4 && 'موعد البدء والساعات اليومية'}
                  {onboardingStep === 5 && 'المعاينة واعتماد الخطة'}
                </h3>
              </div>
              <div className="flex gap-2">
                {[1, 2, 3, 4, 5].map((step) => (
                  <div key={step} className={`h-2.5 rounded-full transition-all ${step <= onboardingStep ? 'w-8 bg-gradient-to-r from-indigo-500 to-purple-500' : 'w-2.5 bg-slate-200 dark:bg-slate-800'}`} />
                ))}
              </div>
            </div>

            {/* STEP 1: STUDENT INFO */}
            {onboardingStep === 1 && (
              <div className="space-y-6">
                <div>
                  <h2 className="text-2xl font-black text-slate-900 dark:text-white mb-2">منو البطل اللي بيتفوق هالسنة؟ 👋</h2>
                  <p className="text-slate-500 dark:text-slate-400 text-xs">أدخل معلوماتك لنخصص لك الخطة الأنسب لمرحلتك الدراسيّة</p>
                </div>

                <div className="space-y-4">
                  <div>
                    <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-2">اسمك الكريم</label>
                    <input 
                      type="text" 
                      value={studentInfo.name} 
                      onChange={(e) => setStudentInfo({ ...studentInfo, name: e.target.value })}
                      className="w-full px-4 py-3.5 rounded-2xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900/60 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 font-bold"
                      placeholder="أدخل اسمك..."
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-2">المرحلة الدراسية</label>
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                      {['الصف العاشر', 'الصف الحادي عشر', 'الصف الثاني عشر'].map((g) => (
                        <button 
                          key={g} 
                          onClick={() => setStudentInfo({ ...studentInfo, grade: g })}
                          className={`p-4 rounded-2xl border text-xs font-bold transition-all flex flex-col items-center justify-center gap-1.5 ${studentInfo.grade === g ? 'border-indigo-500 bg-indigo-500/10 text-indigo-400 shadow-md' : 'border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400 hover:border-slate-300'}`}>
                          <Award className="w-5 h-5 text-indigo-400" />
                          <span>{g}</span>
                        </button>
                      ))}
                    </div>
                  </div>
                </div>

                <button 
                  onClick={() => setOnboardingStep(2)}
                  className="w-full py-4 bg-gradient-to-r from-indigo-600 to-purple-600 hover:opacity-95 text-white font-black rounded-2xl shadow-lg transition-all flex items-center justify-center gap-2 text-sm">
                  التالي: تحديد المواد وتواريخ الاختبارات <ChevronLeft className="w-5 h-5" />
                </button>
              </div>
            )}

            {/* STEP 2: ADD SUBJECTS & EXAM DATES */}
            {onboardingStep === 2 && (
              <div className="space-y-6">
                <div>
                  <h2 className="text-2xl font-black text-slate-900 dark:text-white mb-2">موادك وتواريخ الاختبارات النهائية 📚</h2>
                  <p className="text-slate-500 dark:text-slate-400 text-xs">حدد المواد المشمولة بجدولك وموعد اختبار كل مادة بالترتيب</p>
                </div>

                <div className="p-4 bg-slate-50 dark:bg-slate-900/60 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-3">
                  <h3 className="text-xs font-bold text-slate-800 dark:text-slate-200">إضافة مادة جديدة:</h3>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <input 
                      type="text" 
                      placeholder="اسم المادة (مثال: الأحياء)"
                      value={newSubjectName}
                      onChange={(e) => setNewSubjectName(e.target.value)}
                      className="px-3.5 py-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs focus:outline-none focus:ring-2 focus:ring-indigo-500 font-bold"
                    />
                    <input 
                      type="date"
                      value={newSubjectExamDate}
                      onChange={(e) => setNewSubjectExamDate(e.target.value)}
                      className="px-3.5 py-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs focus:outline-none focus:ring-2 focus:ring-indigo-500 font-bold"
                    />
                  </div>
                  <button 
                    onClick={handleAddSubjectInStep2}
                    className="w-full py-3 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs rounded-xl transition-all flex items-center justify-center gap-1.5">
                    <Plus className="w-4 h-4" /> إضافة المادة للقائمة
                  </button>
                </div>

                <div className="space-y-2.5 max-h-60 overflow-y-auto pr-1">
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300">المواد المضافة ({subjects.length}):</label>
                  {subjects.map((sub) => (
                    <div key={sub.id} className="p-3.5 bg-white dark:bg-slate-900/80 rounded-xl border border-slate-200 dark:border-slate-800 flex items-center justify-between text-xs shadow-sm">
                      <div className="flex items-center gap-2.5">
                        <div className="w-3 h-3 rounded-full bg-gradient-to-r from-indigo-500 to-purple-500" />
                        <div>
                          <span className="font-extrabold text-slate-800 dark:text-slate-200">{sub.name}</span>
                          <div className="text-[11px] text-indigo-400 font-semibold mt-0.5">موعد الاختبار: {sub.examDate}</div>
                        </div>
                      </div>
                      <button 
                        onClick={() => handleRemoveSubject(sub.id)}
                        className="p-2 text-rose-500 hover:bg-rose-500/10 rounded-lg transition-all">
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  ))}
                </div>

                <div className="flex gap-3 pt-2">
                  <button onClick={() => setOnboardingStep(1)} className="w-1/3 py-4 bg-slate-100 dark:bg-slate-800 font-bold rounded-2xl text-slate-600 dark:text-slate-300 text-xs">السابق</button>
                  <button onClick={() => setOnboardingStep(3)} className="w-2/3 py-4 bg-gradient-to-r from-indigo-600 to-purple-600 text-white font-black rounded-2xl shadow-lg text-xs flex items-center justify-center gap-1">
                    التالي: تفاصيل الدروس والمستويات <ChevronLeft className="w-4 h-4" />
                  </button>
                </div>
              </div>
            )}

            {/* STEP 3: LESSON COUNTS & DIFFICULTY */}
            {onboardingStep === 3 && (
              <div className="space-y-6">
                <div>
                  <h2 className="text-2xl font-black text-slate-900 dark:text-white mb-2">عدد الدروس وسرعة الدراسة 📝</h2>
                  <p className="text-slate-500 dark:text-slate-400 text-xs">حدد إجمالي الدروس ومقدرتك اليومية لبناء جدول المذاكرة المتواصلة</p>
                </div>

                <div className="space-y-4 max-h-80 overflow-y-auto pr-1">
                  {subjects.map((sub) => (
                    <div key={sub.id} className="p-4 bg-slate-50 dark:bg-slate-900/60 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-3">
                      <div className="flex justify-between items-center border-b border-slate-200 dark:border-slate-800 pb-2">
                        <span className="font-black text-indigo-400 text-sm">{sub.name}</span>
                        <span className="text-[10px] bg-indigo-500/10 text-indigo-300 px-2.5 py-1 rounded-lg font-bold border border-indigo-500/20">اختبار: {sub.examDate}</span>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                        <div>
                          <label className="block text-[11px] font-bold text-slate-600 dark:text-slate-400 mb-1">إجمالي دروس المادة</label>
                          <input 
                            type="number"
                            min="1"
                            max="50"
                            value={sub.totalLessons}
                            onChange={(e) => updateSubjectDetail(sub.id, 'totalLessons', parseInt(e.target.value) || 1)}
                            className="w-full px-3 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs focus:outline-none focus:ring-2 focus:ring-indigo-500 font-bold"
                          />
                        </div>

                        <div>
                          <label className="block text-[11px] font-bold text-slate-600 dark:text-slate-400 mb-1">أقصى عدد دروس باليوم</label>
                          <input 
                            type="number"
                            min="1"
                            max="10"
                            value={sub.maxLessonsPerDay || 2}
                            onChange={(e) => updateSubjectDetail(sub.id, 'maxLessonsPerDay', parseInt(e.target.value) || 1)}
                            className="w-full px-3 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs focus:outline-none focus:ring-2 focus:ring-indigo-500 font-bold"
                          />
                        </div>
                      </div>

                      <div>
                        <label className="block text-[11px] font-bold text-slate-600 dark:text-slate-400 mb-1">مستوى صعوبة المادة</label>
                        <div className="grid grid-cols-3 gap-2">
                          {[
                            { id: 'easy', label: 'سهلة' },
                            { id: 'medium', label: 'متوسطة' },
                            { id: 'hard', label: 'صعبة' }
                          ].map(diff => (
                            <button
                              key={diff.id}
                              onClick={() => updateSubjectDetail(sub.id, 'difficulty', diff.id)}
                              className={`py-2 rounded-xl text-xs font-bold transition-all ${sub.difficulty === diff.id ? 'bg-indigo-600 text-white shadow-sm' : 'bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400'}`}>
                              {diff.label}
                            </button>
                          ))}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>

                <div className="flex gap-3 pt-2">
                  <button onClick={() => setOnboardingStep(2)} className="w-1/3 py-4 bg-slate-100 dark:bg-slate-800 font-bold rounded-2xl text-slate-600 dark:text-slate-300 text-xs">السابق</button>
                  <button onClick={() => setOnboardingStep(4)} className="w-2/3 py-4 bg-gradient-to-r from-indigo-600 to-purple-600 text-white font-black rounded-2xl shadow-lg text-xs flex items-center justify-center gap-1">
                    التالي: موعد بدء الدراسة وساعاتها <ChevronLeft className="w-4 h-4" />
                  </button>
                </div>
              </div>
            )}

            {/* STEP 4: STUDY START DATE & DAILY HOURS */}
            {onboardingStep === 4 && (
              <div className="space-y-6">
                <div>
                  <h2 className="text-2xl font-black text-slate-900 dark:text-white mb-2">تاريخ البدء وساعات المذاكرة 📅</h2>
                  <p className="text-slate-500 dark:text-slate-400 text-xs">اختر الوقت المناسب للبدء وساعات المذاكرة اليومية المقدورة</p>
                </div>

                <div className="space-y-4">
                  <div>
                    <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-2">تاريخ بدء المذاكرة</label>
                    <input 
                      type="date" 
                      value={studyStartDate} 
                      onChange={(e) => setStudyStartDate(e.target.value)}
                      className="w-full px-4 py-3.5 rounded-2xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 font-bold"
                    />

                    <button
                      onClick={suggestThirtyDaysBeforeFirstExam}
                      className="w-full mt-2.5 py-3 px-4 bg-indigo-500/10 hover:bg-indigo-500/20 text-indigo-400 border border-indigo-500/30 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-2">
                      <Sparkles className="w-4 h-4 text-amber-400" />
                      اقترح لي موعد البداية (قبل أول اختبار بشهر تقريباً)
                    </button>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-2">ساعات المذاكرة اليومية المتاحة</label>
                    <div className="grid grid-cols-4 gap-3">
                      {[2, 3, 4, 5].map((hrs) => (
                        <button 
                          key={hrs} 
                          onClick={() => setDailyHours(hrs)}
                          className={`p-3.5 rounded-2xl border text-xs font-bold transition-all ${dailyHours === hrs ? 'border-indigo-500 bg-indigo-500/10 text-indigo-400 shadow-md' : 'border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400'}`}>
                          {hrs} ساعات
                        </button>
                      ))}
                    </div>
                  </div>
                </div>

                <div className="flex gap-3 pt-2">
                  <button onClick={() => setOnboardingStep(3)} className="w-1/3 py-4 bg-slate-100 dark:bg-slate-800 font-bold rounded-2xl text-slate-600 dark:text-slate-300 text-xs">السابق</button>
                  <button onClick={() => setOnboardingStep(5)} className="w-2/3 py-4 bg-gradient-to-r from-indigo-600 to-purple-600 text-white font-black rounded-2xl shadow-lg text-xs flex items-center justify-center gap-1">
                    التالي: المعاينة وإنشاء الخطة <ChevronLeft className="w-4 h-4" />
                  </button>
                </div>
              </div>
            )}

            {/* STEP 5: PREVIEW & CONFIRM */}
            {onboardingStep === 5 && (
              <div className="space-y-6">
                <div className="text-center">
                  <div className="w-16 h-16 bg-gradient-to-tr from-indigo-600 to-purple-600 text-white rounded-3xl flex items-center justify-center mx-auto mb-3 shadow-lg shadow-indigo-500/20">
                    <Sparkles className="w-8 h-8 animate-pulse" />
                  </div>
                  <h2 className="text-2xl font-black text-slate-900 dark:text-white mb-1">خطة المذاكرة المتواصلة جاهزة! 🚀</h2>
                  <p className="text-xs text-slate-500 dark:text-slate-400">ستدرس مادة واحدة بتركيز تام يوماً بعد يوم حتى تختمها بالكامل قبل الانتقال للبعدها</p>
                </div>

                <div className="p-4 bg-indigo-500/10 rounded-2xl border border-indigo-500/20 text-xs space-y-2.5">
                  <div className="flex justify-between">
                    <span className="text-slate-400">تاريخ بدء الدراسة:</span>
                    <span className="font-extrabold text-indigo-400">{studyStartDate}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">أول اختبار:</span>
                    <span className="font-extrabold text-indigo-400">{generatedPlan?.firstExamDate}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">نظام الدراسة:</span>
                    <span className="font-extrabold text-emerald-400">مذاكرة متواصلة للمادة + مراجعة مسائية للاختبارات</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">إجمالي المواد والدروس:</span>
                    <span className="font-extrabold text-indigo-400">{subjects.length} مواد ({subjects.reduce((a,b)=>a+b.totalLessons,0)} درس)</span>
                  </div>
                </div>

                <div className="flex gap-3">
                  <button onClick={() => setOnboardingStep(4)} className="w-1/3 py-4 bg-slate-100 dark:bg-slate-800 font-bold rounded-2xl text-slate-600 dark:text-slate-300 text-xs">السابق</button>
                  <button 
                    onClick={() => setActiveTab('dashboard')}
                    className="w-2/3 py-4 bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-600 text-white font-black text-sm rounded-2xl shadow-xl hover:opacity-95 transition-all">
                    اعتماد وإنشاء الخطة الآن 🌟
                  </button>
                </div>
              </div>
            )}
          </div>
        )}

        {/* 3. MAIN DASHBOARD TAB */}
        {activeTab === 'dashboard' && (
          <div className="space-y-6">
            
            {/* MOTIVATIONAL BANNER */}
            <div className="p-6 sm:p-8 rounded-3xl bg-gradient-to-r from-indigo-900 via-purple-900 to-slate-900 text-white shadow-2xl border border-indigo-500/30 flex items-center justify-between relative overflow-hidden">
              <div className="z-10 max-w-xl space-y-2">
                <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-indigo-500/20 backdrop-blur-md text-[11px] font-extrabold text-amber-300 border border-indigo-500/30">
                  <Flame className="w-4 h-4 text-amber-400 animate-pulse" /> عبارة اليوم الملهمة
                </div>
                <h2 className="text-2xl sm:text-3xl font-black tracking-tight">
                  هلا يا بطل! جاهز تزرع خطوة جديدة اليوم؟ ✨
                </h2>
                <p className="text-xs sm:text-sm text-indigo-200 font-bold">
                  {MOTIVATIONAL_QUOTES[currentQuoteIndex]}
                </p>
              </div>
              <Sparkles className="hidden sm:block w-32 h-32 text-indigo-500/10 absolute left-4 bottom-0 pointer-events-none" />
            </div>

            {/* STATS OVERVIEW */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="p-5 bg-white/80 dark:bg-[#121427]/80 backdrop-blur-xl border border-slate-200/60 dark:border-slate-800 rounded-3xl shadow-sm">
                <div className="flex justify-between items-center mb-2">
                  <span className="text-xs font-bold text-slate-500 dark:text-slate-400">إجمالي التقدم</span>
                  <Award className="w-4 h-4 text-indigo-400" />
                </div>
                <div className="text-2xl font-black text-slate-900 dark:text-white">{overallStats.progressPct}%</div>
                <div className="w-full bg-slate-200 dark:bg-slate-800 rounded-full h-2 mt-2 overflow-hidden">
                  <div className="bg-gradient-to-r from-indigo-500 to-purple-500 h-full rounded-full transition-all duration-500" style={{ width: `${overallStats.progressPct}%` }} />
                </div>
              </div>

              <div className="p-5 bg-white/80 dark:bg-[#121427]/80 backdrop-blur-xl border border-slate-200/60 dark:border-slate-800 rounded-3xl shadow-sm">
                <div className="flex justify-between items-center mb-2">
                  <span className="text-xs font-bold text-slate-500 dark:text-slate-400">الدروس المنجزة</span>
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                </div>
                <div className="text-2xl font-black text-slate-900 dark:text-white">{overallStats.completedTasks} / {overallStats.totalTasks}</div>
                <span className="text-[10px] text-slate-400 font-medium">مهام مكتملة بنجاح</span>
              </div>

              <div className="p-5 bg-white/80 dark:bg-[#121427]/80 backdrop-blur-xl border border-slate-200/60 dark:border-slate-800 rounded-3xl shadow-sm">
                <div className="flex justify-between items-center mb-2">
                  <span className="text-xs font-bold text-slate-500 dark:text-slate-400">الساعات اليومية</span>
                  <Clock className="w-4 h-4 text-amber-400" />
                </div>
                <div className="text-2xl font-black text-slate-900 dark:text-white">{dailyHours} ساعات</div>
                <span className="text-[10px] text-slate-400 font-medium">ساعات مخصصة للتركيز</span>
              </div>

              <div className="p-5 bg-white/80 dark:bg-[#121427]/80 backdrop-blur-xl border border-slate-200/60 dark:border-slate-800 rounded-3xl shadow-sm">
                <div className="flex justify-between items-center mb-2">
                  <span className="text-xs font-bold text-slate-500 dark:text-slate-400">أول اختبار قادم</span>
                  <CalendarIcon className="w-4 h-4 text-purple-400" />
                </div>
                <div className="text-2xl font-black text-slate-900 dark:text-white">{generatedPlan?.firstExamDate || '---'}</div>
                <span className="text-[10px] text-slate-400 font-medium">فترة الاختبارات النهائية</span>
              </div>
            </div>

            {/* TODAY'S TASKS CARD */}
            <div className="p-6 sm:p-8 bg-white/80 dark:bg-[#121427]/80 backdrop-blur-xl border border-slate-200/60 dark:border-slate-800 rounded-3xl shadow-sm space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-xl font-black text-slate-900 dark:text-white">جدول مهام اليوم 📌</h3>
                  <p className="text-xs text-slate-500 dark:text-slate-400 font-bold">{todayScheduleObj?.date} ({todayScheduleObj?.dayName}) - {todayScheduleObj?.mainSubjectName || 'استراحة'}</p>
                </div>
                <button 
                  onClick={() => setActiveTab('focus')}
                  className="px-4 py-2.5 bg-gradient-to-r from-indigo-600 to-purple-600 text-white font-black text-xs rounded-xl shadow-md hover:opacity-90 transition-all flex items-center gap-1.5">
                  <Clock className="w-4 h-4" /> ابدأ التركيز الآن
                </button>
              </div>

              {todayScheduleObj?.isRest ? (
                <div className="p-8 text-center bg-amber-500/10 rounded-2xl border border-amber-500/20 space-y-2">
                  <div className="w-12 h-12 bg-amber-500/20 text-amber-400 rounded-2xl flex items-center justify-center mx-auto font-black text-xl">☕</div>
                  <h4 className="font-black text-amber-300 text-sm">اليوم يوم راحة واستعادة نشاط!</h4>
                  <p className="text-xs text-amber-400/80">خذ قسطاً من الراحة لتعود بأعلى طاقة لمواصلة التفوق.</p>
                </div>
              ) : todayScheduleObj?.items?.length > 0 ? (
                <div className="space-y-3">
                  {todayScheduleObj.items.map((task) => {
                    const isDone = completedTaskIds.includes(task.id);
                    return (
                      <div key={task.id} className={`p-4.5 rounded-2xl border transition-all flex items-center justify-between ${isDone ? 'bg-slate-100/50 dark:bg-slate-900/40 border-slate-200 dark:border-slate-800/60 opacity-70' : 'bg-white dark:bg-slate-900/90 border-slate-200 dark:border-slate-800 shadow-sm hover:border-indigo-500/40'}`}>
                        <div className="flex items-center gap-3.5">
                          <button 
                            onClick={() => toggleTaskCompletion(task.id)}
                            className={`w-6 h-6 rounded-lg border flex items-center justify-center transition-all ${isDone ? 'bg-emerald-500 border-emerald-500 text-white' : 'border-slate-300 dark:border-slate-700'}`}>
                            {isDone && <Check className="w-4 h-4" />}
                          </button>
                          <div>
                            <span className={`text-xs sm:text-sm font-black ${isDone ? 'line-through text-slate-400' : 'text-slate-800 dark:text-slate-200'}`}>
                              {task.title}
                            </span>
                            <div className="flex items-center gap-2 mt-1">
                              <span className="text-[10px] bg-indigo-500/10 text-indigo-400 font-bold px-2.5 py-0.5 rounded-md border border-indigo-500/20">
                                {task.subjectName}
                              </span>
                            </div>
                          </div>
                        </div>

                        {isDone && (
                          <button 
                            onClick={() => setSelectedTaskForReview(task)}
                            className="px-3 py-1.5 bg-indigo-500/10 text-indigo-400 text-[11px] font-black rounded-xl hover:bg-indigo-500/20 transition-all border border-indigo-500/20">
                            تقييم الاستيعاب
                          </button>
                        )}
                      </div>
                    );
                  })}
                </div>
              ) : (
                <div className="p-8 text-center bg-slate-100/50 dark:bg-slate-900/40 rounded-2xl border border-slate-200 dark:border-slate-800 text-xs text-slate-500">
                  لا يوجد دروس مجدولة لليوم. استمتع بوقتك أو راجع ما تم إنجازه! 🎉
                </div>
              )}
            </div>
          </div>
        )}

        {/* 4. REAL MONTHLY INTERACTIVE CALENDAR GRID TAB */}
        {activeTab === 'calendar' && (
          <div className="space-y-6">
            
            {/* Calendar Controls Bar */}
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 bg-gradient-to-r from-slate-900/90 via-indigo-950/80 to-purple-950/90 backdrop-blur-xl p-6 rounded-3xl border border-indigo-500/30 shadow-2xl relative overflow-hidden">
              <div className="absolute top-0 left-0 w-32 h-32 bg-indigo-500/10 rounded-full blur-2xl pointer-events-none" />
              <div className="z-10">
                <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-500/20 text-indigo-300 text-[10px] font-black border border-indigo-500/30 mb-1">
                  <Sparkles className="w-3.5 h-3.5 text-amber-400 animate-pulse" /> رزنامة النجاح البصرية
                </div>
                <h2 className="text-2xl font-black text-white">الرزنامة الشهرية التفاعلية 📅</h2>
                <p className="text-xs text-indigo-200/80 font-bold">تتبع خطتك المتواصلة بأسلوب بصري ممتع وشيق يفتح النفس للدراسة!</p>
              </div>

              {/* Month Navigation & Subject Filter */}
              <div className="flex flex-wrap items-center gap-3 z-10">
                <div className="flex items-center bg-slate-900/90 p-1.5 rounded-2xl border border-indigo-500/30 shadow-inner">
                  <button onClick={handlePrevMonth} className="p-2 hover:bg-indigo-600/30 rounded-xl text-indigo-300 hover:text-white transition-all">
                    <ChevronRight className="w-5 h-5" />
                  </button>
                  <span className="px-4 text-xs font-black text-white min-w-[120px] text-center">
                    {ARABIC_MONTHS[currentCalendarDate.getMonth()]} {currentCalendarDate.getFullYear()}
                  </span>
                  <button onClick={handleNextMonth} className="p-2 hover:bg-indigo-600/30 rounded-xl text-indigo-300 hover:text-white transition-all">
                    <ChevronLeft className="w-5 h-5" />
                  </button>
                </div>

                <select 
                  value={selectedSubjectFilter}
                  onChange={(e) => setSelectedSubjectFilter(e.target.value)}
                  className="px-4 py-3 rounded-2xl bg-slate-900/90 border border-indigo-500/30 text-white text-xs font-bold focus:outline-none focus:ring-2 focus:ring-indigo-500 shadow-inner">
                  <option value="all">🎨 كل المواد الدراسية</option>
                  {subjects.map(s => (
                    <option key={s.id} value={s.id}>📚 {s.name}</option>
                  ))}
                </select>
              </div>
            </div>

            {/* MONTHLY CALENDAR GRID */}
            <div className="bg-white/80 dark:bg-[#121427]/80 backdrop-blur-xl border border-slate-200/60 dark:border-slate-800 rounded-3xl p-4 sm:p-6 shadow-xl overflow-hidden">
              
              {/* Day Headers (Sun -> Sat) */}
              <div className="grid grid-cols-7 gap-1.5 sm:gap-2.5 mb-3 text-center">
                {['الأحد', 'الإثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت'].map((dayName, idx) => (
                  <div key={idx} className="py-2.5 rounded-xl bg-slate-100 dark:bg-slate-900/80 text-xs font-black text-indigo-500 dark:text-indigo-400 border border-slate-200 dark:border-slate-800 shadow-sm">
                    {dayName}
                  </div>
                ))}
              </div>

              {/* Grid Days */}
              <div className="grid grid-cols-7 gap-1.5 sm:gap-2.5">
                {calendarMonthDays.map((item, idx) => {
                  if (item.isPadding) {
                    return <div key={`pad_${idx}`} className="min-h-[110px] sm:min-h-[135px] rounded-2xl bg-slate-100/30 dark:bg-slate-900/20 border border-slate-200/20 dark:border-slate-800/20 opacity-20 pointer-events-none" />;
                  }

                  const { dayNumber, dateStr, daySchedule } = item;
                  const isRest = daySchedule?.isRest;
                  const mainSubName = daySchedule?.mainSubjectName;
                  const itemsCount = daySchedule?.items?.length || 0;
                  const completedCount = daySchedule?.items?.filter(i => completedTaskIds.includes(i.id)).length || 0;
                  const isFullyDone = itemsCount > 0 && completedCount === itemsCount;
                  const isExamPeriod = daySchedule?.phase === 'exam_period';

                  const filterPass = selectedSubjectFilter === 'all' || 
                    (daySchedule?.items && daySchedule.items.some(i => i.subjectId === selectedSubjectFilter));

                  // Find subject dynamic gradient theme
                  const currentSubObj = subjects.find(s => s.id === daySchedule?.mainSubjectId);
                  const themeGradient = currentSubObj?.color || 'from-indigo-600 to-purple-600';

                  return (
                    <div 
                      key={dateStr}
                      onClick={() => daySchedule && setSelectedCalendarDay(daySchedule)}
                      className={`min-h-[110px] sm:min-h-[135px] p-2 sm:p-3 rounded-2xl border transition-all duration-300 cursor-pointer flex flex-col justify-between relative group hover:-translate-y-1 hover:shadow-xl hover:z-20 ${!filterPass ? 'opacity-20 scale-95' : ''} ${
                        isRest 
                          ? 'bg-gradient-to-br from-amber-500/10 via-amber-500/5 to-transparent border-amber-500/30' 
                          : isExamPeriod 
                          ? 'bg-gradient-to-br from-purple-600/20 via-pink-600/10 to-transparent border-purple-500/50' 
                          : isFullyDone 
                          ? 'bg-gradient-to-br from-emerald-500/20 via-teal-500/10 to-transparent border-emerald-500/40' 
                          : 'bg-white dark:bg-slate-900/80 border-slate-200/80 dark:border-slate-800'
                      }`}>
                      <div>
                        <div className="flex justify-between items-center mb-1.5">
                          <span className={`text-xs font-black px-2 py-0.5 rounded-lg ${isFullyDone ? 'bg-emerald-500 text-white' : 'bg-slate-200 dark:bg-slate-800 text-slate-800 dark:text-slate-200'}`}>
                            {dayNumber}
                          </span>
                          {itemsCount > 0 && (
                            <span className={`text-[9px] font-black px-1.5 py-0.5 rounded-md backdrop-blur-md shadow-sm ${isFullyDone ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30' : 'bg-indigo-500/20 text-indigo-400 border border-indigo-500/30'}`}>
                              {completedCount}/{itemsCount} {isFullyDone ? '✓' : ''}
                            </span>
                          )}
                        </div>

                        {isRest ? (
                          <div className="mt-2 text-center p-1.5 rounded-xl bg-amber-500/10 border border-amber-500/20">
                            <span className="text-[11px] font-black text-amber-400 flex items-center justify-center gap-1">☕ راحة</span>
                          </div>
                        ) : mainSubName ? (
                          <div className="mt-1 space-y-1">
                            <div className={`p-1.5 rounded-xl bg-gradient-to-r ${themeGradient} text-white shadow-md group-hover:scale-105 transition-transform`}>
                              <span className="text-[10px] sm:text-[11px] font-black block truncate text-center leading-tight">
                                {mainSubName}
                              </span>
                            </div>
                            {isExamPeriod && (
                              <span className="text-[9px] bg-pink-500/20 text-pink-400 border border-pink-500/30 px-1.5 py-0.5 rounded-md block text-center font-bold animate-pulse">
                                🌙 مراجعة مسائية
                              </span>
                            )}
                          </div>
                        ) : null}
                      </div>

                      {itemsCount > 0 && !isRest && (
                        <div className="w-full bg-slate-200 dark:bg-slate-800 h-2 rounded-full overflow-hidden p-0.5 mt-2">
                          <div 
                            className={`h-full rounded-full transition-all duration-500 ${isFullyDone ? 'bg-emerald-400' : 'bg-gradient-to-r from-indigo-500 to-pink-500'}`} 
                            style={{ width: `${(completedCount / itemsCount) * 100}%` }} 
                          />
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        )}

        {/* 5. FOCUS ROOM TAB */}
        {activeTab === 'focus' && (
          <div className="max-w-2xl mx-auto space-y-6 text-center">
            <div className="p-8 sm:p-10 bg-white/80 dark:bg-[#121427]/80 backdrop-blur-xl border border-slate-200/60 dark:border-slate-800 rounded-3xl shadow-2xl space-y-8">
              <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-indigo-500/10 border border-indigo-500/30 text-indigo-400 text-xs font-black">
                <Clock className="w-4 h-4 text-amber-400" /> مساحة التركيز بومودورو (Pomodoro)
              </div>

              {/* TIMER DISPLAY */}
              <div>
                <div className="text-7xl sm:text-8xl font-black tracking-tight text-slate-900 dark:text-white font-mono drop-shadow-lg">
                  {String(Math.floor(focusTime / 60)).padStart(2, '0')}:{String(focusTime % 60).padStart(2, '0')}
                </div>
                <span className="text-xs font-bold text-slate-400 mt-3 block">
                  {focusMode === 'study' ? '🎯 جلسة مذاكرة وتركيز عميق (25 دقيقة)' : '☕ استراحة قصيرة واستعادة نشاط (5 دقائق)'}
                </span>
              </div>

              {/* TIMER CONTROLS */}
              <div className="flex justify-center gap-4">
                <button 
                  onClick={() => setIsTimerRunning(!isTimerRunning)}
                  className={`px-10 py-4.5 rounded-2xl font-black text-sm shadow-xl transition-all flex items-center gap-2 ${isTimerRunning ? 'bg-amber-500 hover:bg-amber-600 text-white' : 'bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-600 hover:opacity-95 text-white'}`}>
                  {isTimerRunning ? <Pause className="w-5 h-5" /> : <Play className="w-5 h-5" />}
                  {isTimerRunning ? 'إيقاف مؤقت' : 'ابدأ التركيز'}
                </button>
                <button 
                  onClick={() => { setIsTimerRunning(false); setFocusTime(25 * 60); setFocusMode('study'); }}
                  className="p-4.5 bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 rounded-2xl hover:bg-slate-200 transition-all">
                  <RotateCcw className="w-5 h-5" />
                </button>
              </div>

              {/* AMBIENT AUDIO SOUND GENERATOR */}
              <div className="pt-8 border-t border-slate-200 dark:border-slate-800/80 space-y-4">
                <label className="block text-xs font-black text-slate-700 dark:text-slate-300">أصوات الخلفية الصوتية للتركيز (Ambient Sound Generator)</label>
                <div className="grid grid-cols-3 gap-3">
                  {[
                    { id: 'none', label: 'بدون صوت' },
                    { id: 'rain', label: '🌧️ صوت المطر' },
                    { id: 'waves', label: '🌊 صوت الأمواج' }
                  ].map((snd) => (
                    <button 
                      key={snd.id}
                      onClick={() => setSoundType(snd.id)}
                      className={`py-3 rounded-2xl text-xs font-extrabold transition-all ${soundType === snd.id ? 'bg-indigo-600 text-white shadow-md' : 'bg-slate-100 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400'}`}>
                      {snd.label}
                    </button>
                  ))}
                </div>

                {soundType !== 'none' && (
                  <div className="flex items-center gap-3 pt-2 max-w-xs mx-auto">
                    <VolumeX className="w-4 h-4 text-slate-400" />
                    <input 
                      type="range"
                      min="0"
                      max="0.3"
                      step="0.01"
                      value={soundVolume}
                      onChange={(e) => setSoundVolume(parseFloat(e.target.value))}
                      className="w-full accent-indigo-500"
                    />
                    <Volume2 className="w-4 h-4 text-slate-400" />
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        {/* 6. PROGRESS TAB */}
        {activeTab === 'progress' && (
          <div className="space-y-6">
            <div className="bg-white/80 dark:bg-[#121427]/80 backdrop-blur-xl border border-slate-200/60 dark:border-slate-800 rounded-3xl p-6 sm:p-8 shadow-sm">
              <h2 className="text-xl font-black text-slate-900 dark:text-white mb-1">لوحة إنجازات المواد والتقدم 📊</h2>
              <p className="text-xs text-slate-500 dark:text-slate-400 font-bold mb-6">احصائيات الإنجاز لجدول المذاكرة المتواصلة للمواد</p>

              <div className="space-y-4">
                {subjects.map(sub => {
                  const subTasks = generatedPlan?.schedule?.flatMap(d => d.items).filter(i => i.subjectId === sub.id) || [];
                  const subDoneCount = subTasks.filter(i => completedTaskIds.includes(i.id)).length;
                  const pct = subTasks.length > 0 ? Math.round((subDoneCount / subTasks.length) * 100) : 0;

                  return (
                    <div key={sub.id} className="p-4.5 bg-slate-50 dark:bg-slate-900/60 rounded-2xl border border-slate-200/60 dark:border-slate-800 space-y-2">
                      <div className="flex justify-between items-center text-xs font-black">
                        <span className="text-slate-800 dark:text-slate-200">{sub.name}</span>
                        <span className="text-indigo-400">{pct}% ({subDoneCount}/{subTasks.length} مهام)</span>
                      </div>
                      <div className="w-full bg-slate-200 dark:bg-slate-800 h-2.5 rounded-full overflow-hidden">
                        <div className="bg-gradient-to-r from-indigo-500 to-purple-500 h-full transition-all duration-500" style={{ width: `${pct}%` }} />
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        )}

        {/* 7. STUDY GUIDE TAB */}
        {activeTab === 'guide' && (
          <div className="space-y-6">
            <div className="bg-white/80 dark:bg-[#121427]/80 backdrop-blur-xl border border-slate-200/60 dark:border-slate-800 rounded-3xl p-6 sm:p-8 shadow-sm">
              <h2 className="text-xl font-black text-slate-900 dark:text-white mb-2">كيف أدرس بذكاء؟ 💡</h2>
              <p className="text-xs text-slate-500 dark:text-slate-400 font-bold mb-6">أفضل طرق الاستذكار المثبتة علمياً لطلاب الثانوية العامة</p>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {[
                  { title: 'الاسترجاع النشط (Active Recall)', desc: 'أغلق الكتاب بعد قراءة الدرس وحاول تذكر النقاط الرئيسية وكتابتها أو شرحها لنفسك بصوت عالٍ.' },
                  { title: 'المراجعة المتباعدة (Spaced Repetition)', desc: 'راجع الدرس بعد يوم ثم بعد أسبوع لترسيخ المعلومات في الذاكرة طويلة المدى.' },
                  { title: 'تقنية بومودورو (Pomodoro)', desc: 'ادرس لمدة 25 دقيقة بتركيز تام ثم خذ 5 دقائق استراحة للحفاظ على طاقة عقلك.' },
                  { title: 'حل الاختبارات السابقة', desc: 'أفضل طريقة للتعود على أسئلة الامتحان هي حل النماذج الفعلية للسنوات السابقة.' }
                ].map((g, idx) => (
                  <div key={idx} className="p-5 bg-slate-50 dark:bg-slate-900/60 border border-slate-200 dark:border-slate-800 rounded-2xl space-y-2">
                    <h3 className="font-black text-sm text-indigo-400">{g.title}</h3>
                    <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed font-medium">{g.desc}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* 8. SETTINGS TAB */}
        {activeTab === 'settings' && (
          <div className="max-w-2xl mx-auto space-y-6">
            <div className="bg-white/80 dark:bg-[#121427]/80 backdrop-blur-xl border border-slate-200/60 dark:border-slate-800 rounded-3xl p-6 sm:p-8 shadow-sm space-y-6">
              <h2 className="text-xl font-black text-slate-900 dark:text-white">الإعدادات والتخصيص ⚙️</h2>

              <div className="space-y-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-2">اسم الطالب</label>
                  <input 
                    type="text"
                    value={studentInfo.name}
                    onChange={(e) => setStudentInfo({ ...studentInfo, name: e.target.value })}
                    className="w-full px-4 py-3.5 rounded-2xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-xs font-bold focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-2">ساعات المذاكرة اليومية</label>
                  <input 
                    type="number"
                    min="1"
                    max="8"
                    value={dailyHours}
                    onChange={(e) => setDailyHours(parseInt(e.target.value) || 1)}
                    className="w-full px-4 py-3.5 rounded-2xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-xs font-bold focus:outline-none"
                  />
                </div>

                <div className="pt-4 border-t border-slate-200 dark:border-slate-800">
                  <button 
                    onClick={() => setShowResetConfirmModal(true)}
                    className="w-full py-4 bg-rose-500/10 text-rose-400 border border-rose-500/30 font-black rounded-2xl text-xs hover:bg-rose-500/20 transition-all flex items-center justify-center gap-2">
                    <Trash2 className="w-4 h-4" /> إعادة ضبط البيانات والخطة بالكامل
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

      </main>

      {/* MODAL: COMPREHENSION EVALUATION */}
      {selectedTaskForReview && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-white dark:bg-[#121427] border border-slate-200 dark:border-slate-800 rounded-3xl p-6 max-w-md w-full shadow-2xl space-y-4 text-center">
            <h3 className="text-lg font-black text-slate-900 dark:text-white">شلون كان استيعابك للدرس؟ 🤔</h3>
            <p className="text-xs text-slate-400 font-bold">({selectedTaskForReview.title})</p>

            <div className="space-y-2.5 pt-2">
              <button 
                onClick={() => handleComprehensionFeedback('easy')}
                className="w-full py-3.5 bg-emerald-500/10 text-emerald-400 font-black text-xs rounded-2xl border border-emerald-500/30 hover:bg-emerald-500/20 transition-all">
                🌟 فهمت الدرس تماماً وبشكل رائع
              </button>
              <button 
                onClick={() => handleComprehensionFeedback('review')}
                className="w-full py-3.5 bg-amber-500/10 text-amber-400 font-black text-xs rounded-2xl border border-amber-500/30 hover:bg-amber-500/20 transition-all">
                📖 أحتاج مراجعة وتثبيت إضافي (تعديل الخطة)
              </button>
            </div>

            <button onClick={() => setSelectedTaskForReview(null)} className="text-xs text-slate-500 font-bold hover:text-slate-300 mt-2">إلغاء</button>
          </div>
        </div>
      )}

      {/* MODAL: DAY DETAIL DRAWER */}
      {selectedCalendarDay && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-white dark:bg-[#121427] border border-slate-200 dark:border-slate-800 rounded-3xl p-6 max-w-lg w-full shadow-2xl space-y-4">
            <div className="flex justify-between items-center border-b border-slate-200 dark:border-slate-800 pb-3">
              <div>
                <h3 className="text-base font-black text-slate-900 dark:text-white">{selectedCalendarDay.date} ({selectedCalendarDay.dayName})</h3>
                <p className="text-xs text-indigo-400 font-bold">{selectedCalendarDay.mainSubjectName || 'يوم راحة'}</p>
              </div>
              <button onClick={() => setSelectedCalendarDay(null)} className="p-2 text-slate-400 hover:text-slate-200"><X className="w-5 h-5" /></button>
            </div>

            <div className="space-y-2.5 max-h-60 overflow-y-auto">
              {selectedCalendarDay.items?.length > 0 ? (
                selectedCalendarDay.items.map(t => (
                  <div key={t.id} className="p-3.5 bg-slate-50 dark:bg-slate-900/80 rounded-xl border border-slate-200 dark:border-slate-800 flex justify-between items-center text-xs">
                    <span className="font-extrabold text-slate-800 dark:text-slate-200">{t.title}</span>
                  </div>
                ))
              ) : (
                <div className="text-center py-6 text-xs text-slate-400">لا يوجد مهام خاصة بهذا اليوم</div>
              )}
            </div>

            <button onClick={() => setSelectedCalendarDay(null)} className="w-full py-3 bg-slate-100 dark:bg-slate-800 font-black text-xs rounded-2xl text-slate-300">إغلاق</button>
          </div>
        </div>
      )}

      {/* MODAL: A4 PRINT TIMETABLE */}
      {showPrintModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/90 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white text-slate-900 rounded-3xl p-8 max-w-3xl w-full shadow-2xl space-y-6 text-right print:p-0 print:shadow-none" dir="rtl">
            <div className="flex justify-between items-center border-b pb-4">
              <div>
                <h2 className="text-2xl font-black">جدول خطوتي الدراسية الشامل | KHUTWATI</h2>
                <p className="text-xs text-slate-600 font-bold">الطالب: {studentInfo.name} | {studentInfo.grade} | <span className="text-indigo-600 font-extrabold">إعداد: أ. ساره الغريب</span></p>
              </div>
              <button onClick={() => window.print()} className="px-5 py-2.5 bg-indigo-600 text-white font-bold text-xs rounded-xl shadow-md flex items-center gap-2">
                <Printer className="w-4 h-4" /> طباعة الآن
              </button>
            </div>

            <div className="space-y-4 max-h-[60vh] overflow-y-auto pr-1">
              <table className="w-full text-xs text-right border-collapse">
                <thead>
                  <tr className="border-b-2 border-slate-900 bg-slate-100">
                    <th className="p-2.5 font-black">التاريخ</th>
                    <th className="p-2.5 font-black">اليوم</th>
                    <th className="p-2.5 font-black">المادة الأساسية</th>
                    <th className="p-2.5 font-black">المهام المجدولة</th>
                  </tr>
                </thead>
                <tbody>
                  {generatedPlan?.schedule?.map((day) => (
                    <tr key={day.date} className="border-b border-slate-200">
                      <td className="p-2.5 font-bold">{day.date}</td>
                      <td className="p-2.5">{day.dayName}</td>
                      <td className="p-2.5 font-black text-indigo-700">{day.mainSubjectName || 'راحة'}</td>
                      <td className="p-2.5 text-[11px]">{day.items?.map(i => i.title).join(' | ') || '---'}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <div className="flex justify-between items-center pt-2 text-[11px] text-slate-500 border-t">
              <span>تم إنشاء هذا الجدول بواسطة تطبيق خطوتي الدراسي</span>
              <span className="font-extrabold text-indigo-700">إعداد: أ. ساره الغريب</span>
            </div>

            <button onClick={() => setShowPrintModal(false)} className="w-full py-3 bg-slate-200 font-bold text-xs rounded-2xl text-slate-700">إغلاق المعاينة</button>
          </div>
        </div>
      )}

    </div>
  );
}